export const firebaseConfig = {
 apiKey: "AIzaSyAYnt1KyhKx2gmX8rqg5uQJ55nYFwi0Pcs",
  authDomain: "wash-r-app.firebaseapp.com",
  projectId: "wash-r-app",
  storageBucket: "wash-r-app.firebasestorage.app",
  messagingSenderId: "246464851954",
  appId: "1:246464851954:web:8459179c358b141b08456b",
  measurementId: "G-6VZ3SP4P36"
};